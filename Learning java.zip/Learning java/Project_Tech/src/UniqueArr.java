
public class UniqueArr {
	
	public static boolean checkUnique (int [] a) {
		
		for (int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] == a[j]) {
					return false ;
				}
			}
		}
		return true ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {1,2,3,4,5,6,7} ;
		
		boolean res = checkUnique(a) ;
		System.out.println(res);

	}

}
