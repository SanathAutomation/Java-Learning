import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ProblemsOnArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] str = {"ram", "mohan", "sohan"} ;
		
		Collections.reverse(Arrays.asList(str));
		System.out.println(Arrays.asList(str));

	}

}
