
public class FloorAndCeiling {
	
	
	public static int ceilCheck(int [] a , int x) {
		int left = 0 ;
		int right = a.length -1 ;
		
		int ceil = -1 ;
		
		while (left <= right) {
			int mid = left +(right-left)/2 ;
			
			if (x == a[mid]) {
				return a[mid] ;
			}
			
			else if (x< a[mid]) {
				
				ceil = a[mid] ;
				right = mid -1 ;
			}
			else 
				left = mid +1 ;
		}
		
		return ceil ;
	}
	
	public static int floorCheck (int [] a , int x) {
		int  left = 0 ;
		int right = a.length -1 ;
		int floor = -1 ;
		while (left <= right) {
			int mid = left + (right-left)/2 ;
			if (x == a[mid]) {
				return a[mid] ;
			}
			
			else if (x < a[mid]) {
				right = mid -1 ;
			}
			else {
				
				floor = a[mid] ;
				left = mid + 1 ;
			}
		}
		return floor ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int [] a = {2,4,6,7,9} ;
     for (int i = 0 ; i <= 10 ; i++) {
    	 System.out.println("Floor of " +i+ " is " + floorCheck(a,i) + " and Ceiling of " +i+ " is " +ceilCheck(a,i));
     }
	}

}
