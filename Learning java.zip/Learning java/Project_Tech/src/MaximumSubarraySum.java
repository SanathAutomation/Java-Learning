
public class MaximumSubarraySum {
	
	public static int findSum (int [] a) {
		int maxInt = Integer.MIN_VALUE ;
		int sum = 0 ;
		for (int i = 0 ; i < a.length ; i++) {
			sum = 0 ;
			for (int j = i ; j < a.length ; j++) {
				sum += a[j] ;
				if (sum > maxInt) {
					maxInt = sum ;
				}
			}
		}
		return maxInt ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,-3,4,9,-4,5,1,-8} ;
		System.out.println(findSum(a));
		
		

	}

}
