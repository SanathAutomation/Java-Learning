
public class FindIndex {
	
	public static int index(int [] a, int target) {
		for (int i = 0 ; i < a.length ; i++) {
			if (a[i] == target) {
				System.out.println(i);
			}
		}
		return -1 ;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,4,1,7,9,3} ;
		index(a,1) ;
		
		
		

	}

}
