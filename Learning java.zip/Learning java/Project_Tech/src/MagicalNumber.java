
public class MagicalNumber {
	
	public static int magic (String str) {
		
		int num = 6 ;
		
		for (int i = 0 ; i < 10 ; i++) {
			for (int j = 0 ; j < 10 ; j ++) {
				for (int k = 0 ; k < 10 ; k++) {
					for (int l = 0 ; l < 10 ; l++) {
						for (int m = 0 ; m < 10 ; m++) {
							for (int n = 0 ; n < 10 ; n++) {
								if (i+j+k == l+m+n) {
									int c = 0 ; 
									if (i != str.charAt(0) - '0')  
										c++ ;
									if (j != str.charAt(1) - '0')
										c++ ;
									if (k != str.charAt(2) - '0')
										c++ ;
									if (l != str.charAt(3) - '0')
										c++ ;
									if (m != str.charAt(4) - '0')
										c++ ;
									if (n != str.charAt(5) - '0')
										c++ ;
									
									if (c < num) {
										num = c ;
									}
									
										
									
								}
							}
						}
						
					}
				}
			}
		}
		
		return num ;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "123456" ;
		System.out.println(magic(str));
		
		
	}

}
