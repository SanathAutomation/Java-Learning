
public class MirrorCharacter {
	
	
	public static String mirror (String str) {
        String reverseChar = "zyxwvutsrqponmlkjihgfedcba" ;
		
		String emp = "" ;
		
		for (int i = 0 ; i < str.length() ; i++) {
			emp += reverseChar.charAt(str.charAt(i) - 'a') ;
		}
		
		return emp ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "sanath" ;
		
		
		
		System.out.println(mirror(str));

	}

}
