
public class KthLargestNumber {
	
	public static int kthlargest (int [] a , int total) {
		
		for (int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] > a[j]) {
					int tmp = a[i] ;
					a[i] = a[j] ;
					a[j] = tmp ;
				}
			}
		}
		
		
		
		return a[total - 1] ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,5,1,8,2,9,12,4} ;
		int target = kthlargest(a, 8) ;
		System.out.println(target);
		
		

	}

}
