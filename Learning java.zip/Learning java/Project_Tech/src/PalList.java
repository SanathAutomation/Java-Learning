
public class PalList {
	
	public static boolean check (String str) {
		
		int len = str.length();

	    for(int i = 0; i < len / 2; i++)  {
	        if (str.charAt(i) != str.charAt(len - i - 1))
	            return false;
	    }
	    return true;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ram car racecar paap poop" ;
		String [] s = str.split(" ") ;
	int count = 0 ;
	
	for (int i = 0 ; i < s.length ; i++) {
		if (check(str) == true) {
			count ++ ;
		}
	}
	System.out.println(count);
		
		
		

	}

}
