
public class LongestString {
	
	public static String method (String str) {
		String emp = "" ;
		String [] s = str.split(" ") ;
		for (int i = 0 ; i < s.length ; i++) {
			if (s[i].length() > emp.length()) {
				emp = s[i] ;
			}
		}
		
		return emp ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Find the longest string in sentence" ;
		System.out.println(method(str));

	}

}
