
public class LargestWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Ram is a good boy" ;
		String emp = "" ;
		String [] s = str.split(" ") ;
		for (int i = 0 ; i < s.length ; i++) {
			if (s[i].length() > emp.length()) {
				emp = s[i] ;
			}
		}
		
		System.out.println("Largest word is = " + emp);

	}

}
