
public class PossibilityOfWord {
	
	public static boolean checkPossibility (String s , String q) {
		
		
		int max = 256 ;
		int [] freq = new int [max] ;
		
		for (int i =  0 ; i < s.length() ; i++) 
			freq [s.charAt(i)] ++ ; 
			for (int j = 0 ; j < q.length() ; j++) {
				freq [q.charAt(j)] -- ;
				
				if (freq[q.charAt(j)] < 0) 
					return false ;
				
			}
		
		
		return true ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "olrpiyn" ;
		String q = "lion" ;
		
		if (checkPossibility(s,q)) {
			System.out.println("yes");
		}
		else {
			System.out.println("No");
		}
		

	}

}
