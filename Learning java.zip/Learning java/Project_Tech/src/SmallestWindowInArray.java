
public class SmallestWindowInArray {
	
	//Find the smallest window in an array sorting which will make the entire array sorted
	
	public static void findSubArray (int [] A) {
		int left_index = -1 ;
		int right_index = -1 ;
		int min_value = Integer.MAX_VALUE ;
		int max_value = Integer.MIN_VALUE ; 
		
		for (int i = 0 ; i < A.length ; i++) {
			if (max_value < A[i]) {
				max_value = A[i] ;
			}
			
			if (A[i] < max_value) {
				right_index = i ;
			}
		}
		
		for (int i = A.length-1 ; i >= 0 ; i--) {
			
			if (min_value > A[i]) {
				min_value = A[i] ;
				
			}
			if (A[i] > min_value) {
				left_index = i ;
			}
		}
		if (left_index == -1) {
			System.out.println("Array is already sorted");
			return ;
		}
		System.out.println("Sort Array from Index " +left_index + " to " +right_index);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] A = { 1, 3, 2, 7, 5, 6, 4, 8} ;
		findSubArray(A) ;
		

	}

}
