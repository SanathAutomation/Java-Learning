
public class ReverseEachWordSent {
	
	public static String rev (String str) {
		
		String [] words = str.split(" ") ;
		String emp = "" ;
		for (String w:words) {
			StringBuilder sb = new StringBuilder (w) ;
			sb.reverse() ;
			
			emp += sb.toString()+ " " ;
		}
		
		return emp.trim() ;
		
	}
		
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "This input string will be reversed" ;
		
		System.out.println(rev(str));
		
		
	}

}
