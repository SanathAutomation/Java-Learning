
public class FindSecondLast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int [] a = {2,5,1,9,3,7} ;
    System.out.println(a[a.length-2]);
	}

}
