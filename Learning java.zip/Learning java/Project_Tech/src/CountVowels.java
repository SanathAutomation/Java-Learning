
public class CountVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "JupiTEr" ;
		int count = 0 ;
		for (int i = 0 ; i < str.length() ; i++) {
			if ((str.charAt(i) == 'a' )|| (str.charAt(i) == 'e' ) || (str.charAt(i) == 'i' ) || (str.charAt(i) == 'o' ) || (str.charAt(i) == 'u' )) {
			count ++ ;	
			}
		}
		
		System.out.println(count);
		
		char [] ch = str.toCharArray() ;
		int [] freq = new int [str.length()] ;
		
		for (int i = 0 ; i < str.length() ; i++) {
			freq[i] = 1 ; 
			for (int j = i+1 ; j < str.length() ; j++) {
				if (ch[i] == ch[j] && i != j) {
					freq[i] ++ ;
					ch[j] = '0' ;
				}
			}
		}
		
		for (int i = 0 ; i < freq.length ; i++) {
			if (ch[i] != ' ' && ch[i] != '0') {
				System.out.println(ch[i] + " = " + freq[i]);
			}
		}
		
		int upper = 0 ;
		for (int i = 0 ; i < str.length() ; i++) {
			if (str.charAt(i) >= 'A' && str.charAt(i) <= 'Z') {
				upper ++ ;
			}
		}
		
		System.out.println("Upper is " +upper);

	}

}
