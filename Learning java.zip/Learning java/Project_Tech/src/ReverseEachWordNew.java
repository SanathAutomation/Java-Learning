import java.util.Arrays;

public class ReverseEachWordNew {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str = "I am in Interview" ;
		String [] s = str.split(" ") ;
		
		String emp = "" ;
		
		for (String w : s) {
			StringBuffer sb = new StringBuffer (w) ;
			//sb.append(w) ;
			sb.reverse() ;
			emp += sb.toString() + " " ;
		}
		emp.trim() ;
		System.out.println(emp);
	}

}
