
public class FirstUpperCase {
	
	public static char checkFirst (String str) {
		
		for (int i = 0 ; i < str.length() ; i++) {
			if (Character.isUpperCase(str.charAt(i))) {
				return str.charAt(i) ;
			}
		}
		return 0 ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "sanaTh" ;
		System.out.println(checkFirst(str));

	}

}
