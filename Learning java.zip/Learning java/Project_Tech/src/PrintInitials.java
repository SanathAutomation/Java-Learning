
public class PrintInitials {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Sanath Chakraborty ranjan" ;
		
		System.out.print(Character.toUpperCase(str.charAt(0)));
		
		for (int i = 1 ; i < str.length()-1 ; i++) {
			if (str.charAt(i) == ' ') {
				System.out.print(Character.toUpperCase(str.charAt(i+1)));
				
			}
		}

	}

}
