import java.util.Arrays;

public class Anagram {
	
	public static boolean checkAnagram (String a , String b) {
		char [] s1 = a.toCharArray();
		char [] s2 = b.toCharArray() ;
		
		int n1 = a.length();
		int n2 = b.length() ;
		 if (n1 != n2) {
			 return false ;
		 }
		 
		 Arrays.sort(s1);
		 Arrays.sort(s2);
		 
		 for (int i = 0 ; i < n1 ; i++) {
			 if (s1[i] != s2[i]) {
				 return false ;
			 }
		 }
		 
		 return true ;
			 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "pqrs" ;
		String b = "srqa" ;
		
		if (checkAnagram (a,b)) {
			System.out.println("Ana");
		}
		else {
			System.out.println("Not Ana");
		}
		

	}

}
