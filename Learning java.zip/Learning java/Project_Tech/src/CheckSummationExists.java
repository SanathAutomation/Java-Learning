
public class CheckSummationExists {
	
	public static boolean summation (int [] a , int target) {
		
		for (int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] + a[j] == target && i != j) {
					return true ;
				}
			}
		}
		return false ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] a = {2,3,7,2,9,3} ;
System.out.println(summation(a,12));

	
	}
}
