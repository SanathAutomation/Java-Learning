
import java.util.HashMap;

public class DSA {
	
	public static void remove (int [] a , int n) {
		HashMap <Integer , Boolean> map = new HashMap <> () ;
		
		for (int i = 0 ; i < n ; i++) {
			if (map.get(a[i]) == null) {
				System.out.println(a[i]);
				
				map.put(a[i], true) ;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,4,7,12,2,6,9} ;
		 int n = a.length ;
		 remove(a, n) ;
		
	}

} 
