
public class LargestNumber {
	
	public static int largest (int [] a , int total) {
		int tmp ;
		for (int i = 0 ; i < total ; i++) {
			for (int j = i+1 ; j < total ; j++) {
				if (a[i] > a[j]) {
					tmp = a[i] ;
					a[i] = a[j] ;
					a[j] = tmp ;
				}
			}
		}
		return a[total-1] ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] a = {2,4,1,7,11,9,20,6} ;
		System.out.println(largest(a,8));
		

	}

}
