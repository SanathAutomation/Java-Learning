import java.util.HashSet;
import java.util.Set;

public class SubArrayWithSum0 {
	
	
	public static boolean check(int[] n) {
		
		Set<Integer> s = new HashSet<> () ;
		s.add(0) ;
		int sum = 0 ; 
		
		for (int values : n) {
			sum += values ;
			
			if (s.contains(sum)) {
				return true ;
			}
			s.add(sum) ;
		}
		return false ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] n = {2,3,-5,2,4} ;
		
		if (check(n)) {
			System.out.println("Sub array sum is zero");
		}
		else {
			System.out.println("sum not equal to 0");
		}
		
		
		

	}

}
