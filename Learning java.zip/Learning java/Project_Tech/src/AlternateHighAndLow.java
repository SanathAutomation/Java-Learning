import java.util.Arrays;

//Rearrange an array with alternate high and low elements
public class AlternateHighAndLow {
	
	public static void swapNum(int [] a , int i , int j) {
		int tmp = a[i] ;
		a[i] = a[j] ;
		a[j] = tmp ;
		
	}
	
	public static void rearrange (int [] a) {
		for (int i = 1 ; i < a.length ; i +=2) {
			if (a[i-1] > a[i]) {
				swapNum(a,i-1 , i);
			}
			if (i+1 < a.length && a[i+1] > a[i]) {
				swapNum(a,i+1 , i);
			}
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {1, 2, 3, 4, 5, 6, 7} ;
		
		rearrange(a) ;
		System.out.println(Arrays.toString(a));

	}

}
