
public class ProductOfArray {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,3,7} ;
		int prod = 1 ;
		for (int i = 0 ; i < a.length ; i++) {
			prod *= a[i] ;
		}
			
		System.out.println(prod);

	}

}
