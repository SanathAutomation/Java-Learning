
import java.util.Set;

public class SubArrayWithSumZero {
	
	public static void findSubArr(int [] a) {
		for (int i = 0 ; i < a.length ; i++) {
			int sum = 0 ;
		  for (int j = i ; j < a.length ; j++ ) {
			  sum += a[j] ;
			  if (sum == 0) {
				  System.out.println("Subarray " +i + " to " + j);
			  }
		  }
		}
		
	}
	
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {3, 4, -7, 3, 1, 3, 1, -4, -2, -2} ;
		findSubArr(a) ;
		

	}

}
