
public class FindPair {
	
	public static void findnum (int [] nums , int target) {
		
		for (int i = 0 ; i < nums.length-1 ; i++) {
			for (int j = i+1 ; j < nums.length ; j++) {
				if (nums[i] + nums[j] == target) {
					System.out.println(nums[i] +" and " +nums[j]);
					return ;
				}
			
			}
		}
		System.out.println("Pair not found");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int [] nums = {2, 4, 3, 5, 6, -2, 4, 7, 8, 9} ;
	findnum(nums, 7) ;
	

	}

}
