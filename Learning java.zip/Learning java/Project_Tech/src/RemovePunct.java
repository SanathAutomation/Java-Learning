
public class RemovePunct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "@who #a%re you" ;
		
		str = str.replaceAll("\\p{Punct}", "") ;
		System.out.println(str);

	}

}
