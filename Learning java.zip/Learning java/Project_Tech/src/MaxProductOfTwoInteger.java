
public class MaxProductOfTwoInteger {
	
	public static void max_Value(int [] a) {
		
		int max_Product = Integer.MIN_VALUE ;
		int min_i = -1 ;
		int min_j = -1 ; 
		for (int i =  0; i < a.length-1 ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (max_Product < (a[i] * a[j])) {
					max_Product = a[i] * a[j] ;
					min_i = i ;
					min_j = j ;
					
				}
			}
		}
		System.out.println("Pair is " + a[min_i] + " and " + a[min_j]);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,7,-10 , -3 , 5 , 6 , -4} ;
		max_Value(a) ;
		

	}

}
