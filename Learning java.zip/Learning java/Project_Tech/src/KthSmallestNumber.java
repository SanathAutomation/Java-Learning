
public class KthSmallestNumber {
	
	public static int findSmallest (int [] a , int total) {
		for (int i = 0 ; i < total ; i++) {
			for (int j = i+1 ; j < total ; j++) {
				if (a[i] < a[j]) {
					int tmp = a[i] ;
					a[i] = a[j] ;
					a[j] = tmp ;
				}
			}
		}
		
		return a[total -1] ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,5,1,9,-1,7,5, -3 ,8} ;
		System.out.println(findSmallest(a,9));

	}

}
