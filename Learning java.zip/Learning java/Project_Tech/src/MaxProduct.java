
public class MaxProduct {
	
	
	public static String maxProd (int [] a) {
		
		int max = 0 ;
		String str = "" ;
		
		for (int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] * a[j] > max) {
					max = a[i] * a[j] ;
				str = Integer.toString(a[i]) + " , " + Integer.toString(a[j]) ;	
				
				}
			}
		}
		System.out.println(max);
		return str ;
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] a = {10,20,30,40,50} ;
		System.out.println(maxProd(a));

	}

}
