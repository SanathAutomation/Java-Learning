
public class CountWordsInString {
	
	
	public static String countWords (String str) {
		String [] s = str.split(" ") ;
		System.out.println(s.length);
		return "" ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Ram is a good boy" ;
		countWords(str) ;

	}

}
