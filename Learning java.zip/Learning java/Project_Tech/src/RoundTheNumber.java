
public class RoundTheNumber {
	
	public static int round (int n) {
		
		int a = n/10 * 10 ;
		int b = a + 10 ;
		return n-a > b-n ? b:a ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n = 443 ;
		System.out.println(round(n));

	}

}
