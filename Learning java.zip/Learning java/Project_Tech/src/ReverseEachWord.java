import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ReverseEachWord {
	
	public static void rev (String str) {
		
		String [] s = str.split(" ") ;
		String emp = "" ;
		

for (String st : s) {
	StringBuffer sb = new StringBuffer (st) ;
	sb.reverse() ;
	emp += sb.toString() + " " ;
}
System.out.println(emp);
		
	}
			

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "sanath chakraborty" ;
		rev(str) ;

		
			}

}
