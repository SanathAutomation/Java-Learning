import java.util.Arrays;

public class Insert2DArray {
	
	int [] [] arr = null ;
	
	public Insert2DArray (int rowCount , int colCount) {
		this.arr = new int[rowCount][colCount] ;
		for (int row = 0 ; row < arr.length ; row ++) {
			for (int col = 0 ; col < arr[0].length ; col ++) {
				arr [row][col] = Integer.MIN_VALUE ;
			}
		}
	}
	
	
public void insertValues (int row , int col , int values ) {
	try {
		if (arr [row] [col] == Integer.MIN_VALUE) {
			arr [row] [col] = values ;
			System.out.println("Value is inserted");
		}
		else {
			System.out.println("Already occupied");
		}
		
	}catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("Invalid Index");
	}
}

//Accessing cell values
public void accessCall (int row , int col) {
	System.out.println("Call value is " + row + " col " + col);
	try {
		System.out.println("Req Cell value is " +arr[row][col]);
	}catch (ArrayIndexOutOfBoundsException e) {
		System.out.println("Invalid Index");
	}
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int [] [] arr = {{1,2},{3,4}} ;
		Insert2DArray sda = new Insert2DArray(3,3) ;
		sda.insertValues(0, 0, 10);
		sda.insertValues(0, 0, 20);
		sda.insertValues(0, 1, 50);
		//System.out.println(Arrays.deepToString(sda.arr));
		sda.accessCall(0, 1);
		

	}

}
