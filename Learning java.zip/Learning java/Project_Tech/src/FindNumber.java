
public class FindNumber {
	
	public static void check(int []a, int target) {
		
		for (int i = 0 ; i < a.length ; i++) {
			if (a[i] == target) {
				System.out.println("Target is present");
				
				break ;
			}
			
			//System.out.println("Target is not present");
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,4,8,1,9,10} ;
		check(a,4) ;
		
		

	}

}
