
public class MissingNumber {
	
	public static void missingNumber(int[] intArray) {
		int sum = 0 ;
		for (int i : intArray) {
			sum += i ;
		}
		System.out.println(sum);
		int n = intArray.length ;
		
		int newSum = 10*(10+1)/2 ; // n*(n+1)/2 ;
		System.out.println(newSum);
		
		int missing_num = newSum - sum ;
		System.out.println(missing_num);
		
		
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int intArray[] = {1, 2, 3, 4, 5, 6, 8, 9, 10};
   missingNumber(intArray) ;
	}

}
