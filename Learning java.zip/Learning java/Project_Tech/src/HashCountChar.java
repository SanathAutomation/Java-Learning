import java.util.HashMap;
import java.util.Map;

public class HashCountChar {
	
	public static void findChar (String str) {
		
		char [] ch = str.toCharArray();
		HashMap<Character, Integer> hs = new HashMap <Character, Integer> () ;
		for (char cha: ch) {
			if (hs.containsKey(cha)) {
				hs.put(cha	, hs.get(cha)+1) ;
			}
			else {
				hs.put(cha, 1) ;
			}
		}
		
		for (Map.Entry ent : hs.entrySet()) {
			System.out.println(ent.getKey() + " = " + ent.getValue());
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Sanath Chakraborty" ;
		findChar(str) ;
		

	}

}
