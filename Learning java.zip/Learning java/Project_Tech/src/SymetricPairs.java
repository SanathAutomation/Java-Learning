import java.util.HashSet;
import java.util.Set;

// Pairs with Mirror images are called Symetric pairs

class Pair {
	
	public int x ;
	public int y ;
	 
	Pair(int x , int y) {
		this.x = x ;
		this.y = y ;
		
	}
}



public class SymetricPairs {
	
	
	public static void checkSymetricPairs(Pair [] pairs) {
		
		Set<String> set = new HashSet<> () ;
		
		// LOGIC FROM HERE
		for (Pair myPair: pairs) {
			
			String P = "{" +myPair.x + " ," + myPair.y + "} " ;
			set.add(P) ;
			
			String revPair = "{" +myPair.y + " ," + myPair.x + "} " ;
			
			if (set.contains(revPair)) {
				System.out.println(P + " |" +revPair);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pair [] pairs = {new Pair(3,4) ,
				new Pair(1,2) , new Pair (4,3) ,
				new Pair (7,10) , new Pair(2,1) ,
				new Pair(1,7)} ;
		checkSymetricPairs(pairs) ;
		

	}

}
