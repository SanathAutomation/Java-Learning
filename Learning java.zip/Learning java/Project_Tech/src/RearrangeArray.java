import java.util.Arrays;

public class RearrangeArray {
	
	public static int index (int []a , int target) {
		
		int i = 0 ; 
		int n = a.length ;
		
		while (i < n) {
			if (a[i] == target) {
				return i ;
			}
			else {
				i = i + 1 ; 
			}
		}
		
		return -1 ;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,3,-1,5,-4,-2} ;
		System.out.println(RearrangeArray.index(a, 2));
		
		
		
		

	}

}
