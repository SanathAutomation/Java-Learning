
public class RecursiveRange {

	
		
		public static int recRange(int num) {
			
			if (num <= 0) {
				return 0 ;
			}
			
			return num + recRange(num-1) ;
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println(recRange(6));
		
	}

}
