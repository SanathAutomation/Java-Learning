// if i < j , but a[i] > a[j] . This pair is called Inversion of array . 

// Using Brute Force attack


public class InversionCount {
	
	
	public static int findInversion(int [] a) {
		
		int count = 0 ;
		for (int i = 0 ; i < a.length ; i++) {
			
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] > a[j]) {
					count ++ ;
				}
			}
		}
		return count ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,5,1,8,2} ;
		System.out.println(findInversion(a));
     
	}

}
