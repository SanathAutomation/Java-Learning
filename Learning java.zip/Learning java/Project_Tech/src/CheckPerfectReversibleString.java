
public class CheckPerfectReversibleString {
	
	public static boolean check (String str) {
		int i = 0 ;
		int n = str.length()-1 ;
		
		while (i < n) {
			if (str.charAt(i)!=  str.charAt(n)) 
				return false ;
				i++ ;
				n-- ;
			
			
		}
		
		return true ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "racecar" ;
		if (check(str)) {
			System.out.println("It is perfect reversible string");
		}
		else {
			System.out.println("Not perfect");
		}
		

	}

}
