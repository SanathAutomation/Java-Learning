import java.util.Arrays;

public class ReverseArray {
	
	
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

   int [] a = {2,4,1,7,3,9} ;
   int tmp = 0; 
   
   for (int i = 0 ; i < a.length/2 ; i++) {
	   tmp = a[i] ;
	   a[i] = a[a.length -1 -i] ;
	   a[a.length-1-i] = tmp ;
   }
   
   System.out.println(Arrays.toString(a));
	}

}
