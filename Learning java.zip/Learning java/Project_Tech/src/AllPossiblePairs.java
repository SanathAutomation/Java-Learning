
public class AllPossiblePairs {
	
	public static void findPairs (int [] arr) {
		for (int i = 0 ; i < arr.length ; i++) {
			for (int j = 0 ; j < arr.length ; j++) {
				System.out.println(arr[i] + ", " +arr[j]);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {1,3,5,7} ;
		findPairs(a) ;
		

	}

}
