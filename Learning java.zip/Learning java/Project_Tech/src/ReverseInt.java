
public class ReverseInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int [] a = {2,4,1,7,3,9,5} ;
 for (int i = a.length-1 ; i >=0 ; i--) {
	 System.out.println(a[i]);
 }
	}

}
