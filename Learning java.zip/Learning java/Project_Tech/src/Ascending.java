import java.util.Arrays;

public class Ascending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {2,4,18,4,12,9} ;
		int tmp ;
		for (int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] > a[j]) {
					tmp = a[i];
					a[i] = a[j];
					a[j] = tmp ;
					
				}
				
			}
			
		}
		
		for (int i = 0 ; i < a.length ; i++) {
			System.out.print(a[i]+ " ");
		}
	}

}                                                 
