
public class ReverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "sanath is a good boy" ;
		String [] s = str.split(" ") ;
		String emp = "" ;
		
		for (int i = s.length-1 ; i >= 0 ; i--) {
			emp += s[i] +" " ;
		}
		System.out.println(emp);
	}

}
