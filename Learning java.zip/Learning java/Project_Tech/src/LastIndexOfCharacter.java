
public class LastIndexOfCharacter {
	
	public static int last (String str , char c) {
	
		int index = -1 ;
     for (int i = 0 ; i < str.length() ; i++) 
	  if (str.charAt(i) == c) 
		  index = i ;
		  return index ;
     
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "sanaths" ;
		System.out.println(last(str,'s'));
		

	}

}
