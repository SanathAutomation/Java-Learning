import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class IsomorphicStrings {
	
	public static boolean isIsomorphic(String X , String Y) {
		
		if (X.length() != Y.length()) {
			return false ;
		}
		if (X == null || Y == null) {
			return false ;
		}
		
		Map <Character, Character> map = new HashMap<> () ;
		Set <Character> set = new HashSet <> () ;
		
		
		
		for (int i = 0 ; i < X.length() ; i++) {
			char x = X.charAt(i) ;
			char y = Y.charAt(i) ;
			
			if (map.containsKey(x)) {
				if (map.get(x) != y) {
					return false ;
				}
			}
			else {
				if (set.contains(y)) {
					return false ;
				}
				map.put(x, y) ;
				set.add(y) ;
			}
		}
		return true ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// String s = "ACADBB" ;
		// String b = "XCXDPP" ;
		String X = "ACADBB" ;
		String Y = "XCXDPP" ;
		if (isIsomorphic(X,Y)) {
			System.out.println("Isomorphic");
		}
		else {
			System.out.println("Not isomorphic");
		}
		

	}

}
