
public class CheckNumDivby3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n = 30 ;
		if (n%3 == 0) {
			System.out.println("Divisible");
			
		}
		else {
			System.out.println("Not div");
		}

	}

}
