
public class MaxSumPathOfTwoArray {
	
	//Find the max summation by traversion from 2 arrays. We can start from either array, but we can switch between arrays only through its common elements.
  public static int findMaxSumPath (int [] X , int [] Y) {
	  int m = X.length ;
	  int n = Y.length ;
	  
	  int i = 0 ;
	  int j = 0 ; 
	  int sum = 0;
	  int sum_x = 0 ;
	  int sum_y = 0 ;
	  
	  // loop till x and y are empty
	  while (i < m && j < n) {
		  
		  while (i < m-1 && X[i] == X[i+1]) {
			  sum_x += X[i++] ;
		  }
		  
		  while (j < n-1 && Y[j] == Y[j+1]) {
			  sum_y += Y[j++] ;
		  }
		  
		  //If current element of Y is less than current element of X
		  if (Y[j] < X[i]) {
			  sum_y += Y[j] ;
			  j++ ;
		  }
		//If current element of X is less than current element of Y
		  else if (X[i] < Y[j]) {
			  sum_x += X[i] ;
			  i++ ;
		  }
		  else {
			  sum += Integer.max(sum_x, sum_y) + X[i] ;
			  i++ ;
			  j++ ;
			  
			  sum_x = 0 ; 
			  sum_y = 0 ;
		  }
		  
	  }
	  
	  //process the remaining element
	  while (i < m) {
		  sum_x += X[i++] ;
	  }
	  while (j < n) {
		  sum_y += Y[j++] ;
		  
	  }
	  
	  sum += Integer.max(sum_x, sum_y) ;
	  return sum ;
  }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] X = { 3, 6, 7, 8, 10, 12, 15, 18, 100 };
	     int[] Y = { 1, 2, 3, 5, 7, 9, 10, 11, 15, 16, 18, 25, 50 };
	     System.out.println("Max sum is "+ findMaxSumPath(X,Y));

	}

}
