
public class PrintFrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = {3,4,6,1,3,4,4,6,2} ;
		int [] freq = new int [a.length] ;
		
		for (int i = 0 ; i < a.length ; i++) {
			freq[i] = 1 ;
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] == a[j] && i != j) {
					freq[i] ++ ;
					a[j] = '0' ;
				}
			}
		}
		
		for (int i = 0 ; i < freq.length ; i++) {
			if (a[i] != ' ' && a[i] != '0') {
				System.out.println(a[i] + " = " + freq[i]);
			}
		}

	}

}
