
public class BinarySearchIterative {
	
	
	public static int check(int [] a , int target) {
		
		int left = 0 ; 
		int right = a.length -1 ;
		
		while (left <= right) {
			
			int mid = left + (right-left)/2 ;
			if (target == a[mid]) {
				return mid ;
			}
			else if (target < a[mid]) {
				right = mid -1 ;
			}
			else {
				left = mid + 1 ;
			}
		}
		return -1 ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int [] a = {2,4,8,9,11,15,16,19} ; // NOTE : Array must be sorted
      int index = check(a,8); 
      if (index != -1) {
    	  System.out.println(index);
      }
      else {
    	  System.out.println("Number not found");
      }
	}

}
