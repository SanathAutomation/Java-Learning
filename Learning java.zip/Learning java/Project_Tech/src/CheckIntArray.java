

public class CheckIntArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "I am in Interview" ;
		String [] s = str.split(" ") ;
		String emp = "" ;
		
		for (int i = s.length-1 ; i >=0 ; i--) {
			emp += s[i] + " " ;
		}
		
		System.out.println(emp);

	}

}



