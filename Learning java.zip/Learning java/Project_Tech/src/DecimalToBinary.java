
public class DecimalToBinary {
	
	public static int decimalToBin(int n) {
		if (n==0) {
			return 0 ;
		}
		else if (n < 0) {
			return -1 ;
		}
		return n%2 + 10*decimalToBin(n/2) ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println(decimalToBin(10));
	}

}
