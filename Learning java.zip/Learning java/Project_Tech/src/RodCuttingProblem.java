
public class RodCuttingProblem {
	
	public static int priceRod(int [] a , int n) {
		
		
		if (n == 0) {
			return 0 ;
		}
		int max_value = Integer.MIN_VALUE ;
		
		for (int i = 1 ; i <= n ; i++) {
			int cost = a[i-1] + priceRod(a , n-i) ;
			
			if (cost > max_value) {
				max_value = cost ;
			}
		}
		return max_value ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int [] a = { 1, 5, 8, 9, 10, 17, 17, 20 };
  int n = 4 ;
  System.out.println(priceRod(a,n));
	}

}
