import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class PairWithGivenSum {
	
	
	public static void checkPair (int [] n , int target) {
		/*for (int i = 0 ; i < n.length -1 ; i++) {
			
			for (int j = i+1 ; j < n.length; j++) {
				if (n[i] + n[j] == target) {
					System.out.println("Target matched " + n[i]+" " + n[j]);
					return ;
				}
				
			}
			
		}
		System.out.println("Target not found"); */
		//Set <Integer> set = new HashSet<> () ;
		Arrays.sort(n);
		
		int low = 0 ;
		int high = n.length-1 ;
		
		while (low < high) {
			if (n[low] + n[high] == target) {
				System.out.println("Target is present " +n[low] + " ," +n[high] );
				return ;
			}
			else if (n[low] + n[high] < target) {
				low ++ ;
			}
			else 
				high -- ;
		}
		
		System.out.println("Match not found");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] n = {2,5,7,9,5,3} ;
		checkPair(n,7) ;
		

	}

}
