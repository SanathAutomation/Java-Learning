
public class PermutationCheck {
	
	public static boolean checkPer (int [] array1 , int [] array2) {
		
		int sum1 = 0 ;
		int sum2 = 0 ;
		int pro1 = 1 ;
		int pro2 = 1 ;
		
		for (int numbers1:array1) {
			sum1 += numbers1 ;
			pro1 *= numbers1 ;
		}
		for (int numbers2:array2) {
			sum2 += numbers2 ;
			pro2 *= numbers2 ;
		}
		if (sum1 == sum2 && pro1 == pro2) {
			return true ;
		}
		
		return false ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1 = {1,2,3,4,5};
		int[] array2 = {4,1,2,3,4};
		System.out.println(checkPer(array1 , array2));

	}

}
