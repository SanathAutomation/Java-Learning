
public class GetPair {
	
	public static String getPair(int [] a , int target) {
		String value = "" ;
		for(int i = 0 ; i < a.length ; i++) {
			for (int j = i+1 ; j < a.length ; j++) {
				if (a[i] + a[j] == target) {
					value += a[i] +" and "+ a[j] + " , " ;
				}
			}
		}
		return value ;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int [] a = {2, 4, 3, 5, 6, -2, 4, 7, 8, 9} ;
      
      System.out.println(getPair(a , 7));
	}

}
