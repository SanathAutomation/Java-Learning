
public class ArrayListToArray {
	
	
	public static int smallest (int []a , int target) {
		
		int tmp ; 
		for (int i = 0 ; i < target ; i++) {
			for (int j = i+1 ; j < target ; j++) {
				if (a[i] > a[j]) {
					tmp = a[i] ;
					a[i] = a[j] ;
					a[j] = tmp ;
				}
			}
		}
		
		return a[target -1] ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] a = {2,4,7,1,5,9} ;
		int number = ArrayListToArray.smallest(a, 6) ;
		System.out.println(number);
		

	}

}
