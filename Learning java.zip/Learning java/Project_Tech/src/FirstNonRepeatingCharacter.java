
public class FirstNonRepeatingCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Sanath" ;
		
		for (char i : str.toCharArray()) {
			if (str.indexOf(i) == str.lastIndexOf(i)) {
				System.out.println("First non repeating char is " + i );
				break ;
			}
		}

	}

}
