
public class Test {
	
	public static void getChar (String str) {
		
		String [] s  = str.split(" ") ;
		String emp = "" ;
		for (int i = s.length -1 ; i >=0 ; i--) {
			emp += s[i] + " " ;
			
		}
		System.out.println(emp);
				
		
	}
	
	public static void main(String[] args) {
		String str = "selenium is good for testers" ;
		getChar(str);
		
		
	}
	
}