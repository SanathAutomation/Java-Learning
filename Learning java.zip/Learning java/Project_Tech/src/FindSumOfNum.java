import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class FindSumOfNum {
	
	public static int findSum(String str) {
		int sum = 0 ;
		String tmp = "0" ;
		for (int i = 0 ; i < str.length(); i++) {
			char ch = str.charAt(i) ;
			if (Character.isDigit(ch)) {
				tmp += ch ;
			}
			else {
				sum += Integer.parseInt(tmp) ;
				tmp = "0" ;
			}
			
		}
		return sum+Integer.parseInt(tmp) ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "12qwe3oi35qakc" ;
		int num = findSum(str) ;
		System.out.println(num);
	}

}
