
public class Solve {

	
		// TODO Auto-generated method stub
		
			public static void main(String args[ ]){

			boolean b1 = true;
			boolean b2 = false;

			System.out.println(
			Boolean.compare(b2, b1));

			}
			

	}


