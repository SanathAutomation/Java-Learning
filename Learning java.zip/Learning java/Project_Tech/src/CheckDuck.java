
public class CheckDuck {
	
	public static boolean check (String str) {
		int n = str.length() ;
		int i = 0 ;
		
		while (i < n && str.charAt(i) == '0') 
			i++ ;
			
		
		
		while (i < n) {
			if (str.charAt(i) == '0') 
				
				return true ;
			i++ ;
			
		}	
		
		return false ;
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "7002" ;
		if (check(str)) {
			System.out.println("Duck");
		}
		else {
			System.out.println("Not duck");
		}
		
		

	}

}
