
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 12321 ;
		int i = 0  ;
		int sum = 0 ; 
		int tmp  ;
		
		tmp = n ;
		while (n > 0) {
			
			int r = n%10 ;
			sum = (sum*10)+ r ;
			n = n/10 ;
			
		}
		if (tmp == sum) {
			System.out.println("Pal");
		}
		else {
			System.out.println("Not pal");
		}
	}

}
