
public class PowerOfNum {
	
	public static int powerOfNumbers (int base , int exp) {
		
		if (exp == 0) {
			return 1 ;
		}
		else if (exp == 1) {
			return base ;
		}
		else if (exp < 0) {
			return -1 ;
		}
		return base * powerOfNumbers(base, exp-1) ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(powerOfNumbers(2,3));

	}

}
