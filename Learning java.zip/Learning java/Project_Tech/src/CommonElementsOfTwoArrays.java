
public class CommonElementsOfTwoArrays {
	
	public static void findCommon (int [] X , int [] Y) {
		for (int i = 0 ; i < X.length ; i++) {
			for (int j = 0 ; j < Y.length ; j++) {
				if (X[i] == Y[j]) {
					System.out.println(Y[j]);
					break ;
					
				}
				
				
			}
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] X = {3,1,6,2,9,4} ;
		int [] Y = {5,1,7,6,8} ;
		findCommon (X,Y) ;

	}

}
