
public class RemoveRepeatedChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "sanath" ;
		
		char [] ch = str.toCharArray() ;
		
		for (int i = 0 ; i < str.length() ; i++) {
			for (int j = 0 ;  j < str.length() ; j++) {
				if (ch[i] == ch[j] && i != j) {
					System.out.print(ch[j] + " and position is " + j);
					System.out.println(str.replace(ch[j],' '));
				}
			}
		}

	}

}
