import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Test {
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "my name is hero" ;
		String emp = "" ;
		
		String [] s1 = str.split(" ") ;
		
		for (String s : s1) {
			
		
		StringBuilder sb = new StringBuilder (s) ;
		
		sb.reverse() ;
		emp += sb.toString()+ " " ;
		
		}
		System.out.println(emp);
	}
}
